import json
import os
import time
import urllib.error
import urllib.request
import uuid

import hasher


# O usuário aleatório mantém este teste separado de contas existentes.
SERVER_PORT = os.environ.get(
    "SECBANK_SERVER_PORT", os.environ.get("SECBANK_PORT", "8080")
)
BASE_URL = f"http://127.0.0.1:{SERVER_PORT}"


def enviar(ruta: str, datos: bytes) -> tuple[int, str]:
    nonce = str(uuid.uuid4())
    timestamp = str(time.time())
    mensaje = datos + b"|" + nonce.encode("utf-8") + b"|" + timestamp.encode("utf-8")
    request = urllib.request.Request(
        f"{BASE_URL}{ruta}",
        data=datos,
        headers={
            "Content-Type": "application/json",
            "X-Signature": hasher.crear_hash_signature(mensaje),
            "X-Nonce": nonce,
            "X-Timestamp": timestamp,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request) as respuesta:
            return respuesta.status, respuesta.read().decode("utf-8")
    except urllib.error.HTTPError as error:
        return error.code, error.read().decode("utf-8")


usuario = f"fuerza_{uuid.uuid4().hex[:8]}"
password_correcta = "SuperClave2026!"
datos_registro = json.dumps(
    {"usuario": usuario, "password": password_correcta}
).encode("utf-8")
codigo, mensaje = enviar("/signin", datos_registro)
if codigo != 200:
    raise RuntimeError(f"No fue posible crear el usuario: HTTP {codigo}: {mensaje}")

print("Probando tres contraseñas incorrectas...")
for intento in range(1, hasher.MAX_INTENTOS + 1):
    datos_login = json.dumps(
        {"usuario": usuario, "password": f"incorrecta{intento}"}
    ).encode("utf-8")
    codigo, mensaje = enviar("/login", datos_login)
    print(f"Intento {intento}: HTTP {codigo} - {mensaje}")
    if codigo != 401:
        raise RuntimeError(
            f"El intento incorrecto {intento} respondió HTTP {codigo}: {mensaje}"
        )

print("Probando a seguir con la contraseña correcta...")
datos_login = json.dumps(
    {"usuario": usuario, "password": password_correcta}
).encode("utf-8")
codigo, mensaje = enviar("/login", datos_login)
if codigo == 429:
    print(f"Defensa activa: cuenta bloqueada - HTTP {codigo}: {mensaje}")
else:
    raise RuntimeError(
        f"La cuenta no quedó bloqueada: HTTP {codigo}: {mensaje}"
    )
