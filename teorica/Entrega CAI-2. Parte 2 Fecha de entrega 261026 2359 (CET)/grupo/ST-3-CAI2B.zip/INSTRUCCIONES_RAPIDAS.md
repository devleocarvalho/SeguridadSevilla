# GUÍA DE INSTRUCCIONES RÁPIDAS PARA EL EQUIPO (ST-3)
**Práctica:** CAI 2 (Parte 2) — Seguridad en Sistemas Informáticos y en Internet  
**Equipo:** Security Team 3 (ST-3 / Grupo 3)  
**Integrantes:** Kleber Leonardo de Carvalho | Paula Benítez | Luigui Juan Guillermo Ramos  

---

Esta guía rápida está pensada para que cualquier compañero del equipo o evaluador pueda reproducir, verificar y validar todas las pruebas de laboratorio en menos de dos minutos.

---

## 0. Verificación Automática "Todo en Uno" (Recomendado)

Hemos preparado un script que ejecuta automáticamente todas las pruebas de los tres apartados, comprueba los hashes y valida el PDF:

```bash
cd /home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados
chmod +x verificar_todo.sh
./verificar_todo.sh
```

---

## 1. Requisitos del Sistema
- **Python 3:** con las librerías `opencv-python`, `matplotlib`, `cryptography` y `markdown`.
- **Java:** OpenJDK 11 o superior instalado (funciona con la versión del sistema o con el JDK de `Ejercicio y contenidos`).

Si falta alguna librería en un equipo nuevo:
```bash
pip install opencv-python matplotlib cryptography markdown
```

---

## 2. Apartado a): Banco de Pruebas de Robustez LSB frente a Distorsiones

Para ejecutar los ensayos de resistencia con 4 órdenes de ruido **Salt & Pepper** y 4 órdenes de recorte **Crop**:

```bash
cd /home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados
python3 scripts/ensayos_robustez_lsb.py
```

**Qué hace este script:**
1. Incrusta una firma médica real de 512 bytes en una radiografía BMP de 500 KB usando VSL.
2. Aplica 4 niveles de ruido Salt & Pepper (0.5%, 1.0%, 2.0%, 5.0%) y calcula el BER (tasa de error de bit) y PSNR.
3. Aplica 4 niveles de recorte Crop (2%, 5%, 10%, 20%) y comprueba la pérdida de sincronización y fallo de cabecera.

---

## 3. Apartado b): Estegoanálisis y Extracción en `Dibujo.bmp`

### 3.1. Estegoanálisis Estadístico Chi-Cuadrado (Herramienta Independiente a VSL)
Para detectar si hay información oculta y en qué fila termina exactamente:

```bash
cd /home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados
python3 scripts/analisis_chicuadrado.py "CAI2/CAI2-Parte2/Ejercicio y contenidos/Dibujo.bmp"
```

*Resultado esperado:* Verás que la probabilidad es **$P = 1.000$ (100% de certeza de esteganografía)** hasta el 86.60% de la imagen (Fila 292, píxel 98.941), y luego cae bruscamente a $P = 0.000$.

### 3.2. Extracción Forense del Mensaje Oculto en Python
Para extraer el payload, verificar la firma ZIP y recuperar la imagen confidencial `a5fde.png`:

```bash
cd /home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados
python3 scripts/extraer_esteganografia.py
```

*Resultado esperado:* Extrae `payload_extraido.zip` (37.099 bytes) y descomprime `a5fde.jpg` / `a5fde.png`, que contiene el **Plano de Evacuación y Seguridad Contra Incendios** del hospital.

### 3.3. Extracción Alternativa usando VSL por Consola (CLI)
Si queréis probar el comando exacto de VSL en terminal:

```bash
cd /home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2
java -cp "Ejercicio y contenidos/vsl-1.1/modules/vsl-module-steganography-lsb.jar:Ejercicio y contenidos/vsl-1.1/lib/*" \
     pl.edu.zut.wi.vsl.modules.steganography.lsb.LsbImpl \
     "Ejercicio y contenidos/Dibujo.bmp" Resultados/payload_vsl.zip 0 0
```

### 3.4. Extracción usando la Interfaz Gráfica de VSL (GUI)
1. Abrir la GUI de VSL:
   ```bash
   cd "/home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Ejercicio y contenidos"
   java -jar vsl-1.1/vsl-app-1.1-linux.jar
   ```
2. En la barra izquierda, arrastrar al lienzo:
   - **Image input** $\rightarrow$ Doble clic y seleccionar `Dibujo.bmp`.
   - **vsl-module-steganography-lsb** $\rightarrow$ Configurar en modo `Decode`, `startbits = 0`, `endbits = 0`.
   - **Message output** $\rightarrow$ Indicar como salida `payload_gui.zip`.
3. Conectar las flechas: `Image input` $\rightarrow$ `LSB Module` $\rightarrow$ `Message output`.
4. Pulsar el botón verde **Run** (Play) en la barra superior.

---

## 4. Apartado c): Demostración Forense de Filtración Visual en Cifrado ECB

Para comprobar por qué el hospital **NO puede estar tranquilo** con las firmas BMP cifradas con AES-256:

```bash
cd /home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados
python3 scripts/demostracion_ecb_bmp.py
```

**Qué genera:**
- Crea una firma digitalizada de médico con su nombre y NIF en formato BMP.
- La cifra con AES-256 en modo **ECB** y en modo **CBC**.
- Podéis abrir `apartado_c/firma_medico_cifrada_ecb.png`: **el nombre del médico, el NIF y el trazo de la firma se leen perfectamente a simple vista** debido a que los bloques de fondo blanco uniforme generan patrones cifrados repetitivos.

---

## 5. Recompilación del PDF Oficial y Empaquetado

Si realizáis cualquier cambio en el informe Markdown (`ST-3-CAI2B.md`):

```bash
cd /home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados

# 1. Compilar el PDF (verificando exactamente 10 páginas):
python3 scripts/generar_pdf_cai2b.py

# 2. Regenerar el archivo ZIP de entrega:
python3 -c "
import os, zipfile, shutil
base = '/home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados'
zip_f = os.path.join(base, 'ST-3-CAI2B.zip')
items = ['ST-3-CAI2B.pdf', 'ST-3-CAI2B.md', 'INSTRUCCIONES_RAPIDAS.md', 'INSTRUCCIONES_VSL_Y_REPRODUCCION.txt', 'verificar_todo.sh', 'a5fde.png', 'a5fde.jpg', 'payload_extraido.zip', 'graficas', 'apartado_c', 'scripts']
with zipfile.ZipFile(zip_f, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    for item in items:
        p = os.path.join(base, item)
        if os.path.isfile(p): zf.write(p, arcname=item)
        elif os.path.isdir(p):
            for r, d, files in os.walk(p):
                for f in files: zf.write(os.path.join(r, f), arcname=os.path.relpath(os.path.join(r, f), base))
shutil.copy2(zip_f, '/home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/ST-3-CAI2B.zip')
shutil.copy2(os.path.join(base, 'ST-3-CAI2B.pdf'), '/home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/ST-3-CAI2B.pdf')
print('ZIP y PDF actualizados correctamente!')
"
```

---

## 6. Resumen de Archivos Finales para la Entrega
- **Informe PDF:** [`CAI2/CAI2-Parte2/Resultados/ST-3-CAI2B.pdf`](file:///home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados/ST-3-CAI2B.pdf) (Exactamente 10 páginas con portada, firmas de aprobación y anexo confidencial).
- **Archivo Comprimido:** [`CAI2/CAI2-Parte2/Resultados/ST-3-CAI2B.zip`](file:///home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados/ST-3-CAI2B.zip) (Incluye informe, imágenes crudas, scripts y evidencias).
