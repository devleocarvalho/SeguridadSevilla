#!/usr/bin/env python3
"""
Herramienta Pericial de Estegoanálisis Estadístico Chi-Cuadrado (Westfeld & Pfitzmann, 1999)
Seguridad en Sistemas Informáticos e Internet - CAI 2 Parte 2
Security Team 3 (ST-3)
"""
import sys
import math
import cv2
import numpy as np

def regularized_gamma_q(s, x):
    """Función gamma incompleta regularizada superior Q(s, x)."""
    if x <= 0.0 or s <= 0.0: return 1.0
    if x < s + 1.0:
        sum_val = 1.0 / s
        term = sum_val
        for n in range(1, 150):
            term *= x / (s + n)
            sum_val += term
            if abs(term) < abs(sum_val) * 1e-12: break
        return 1.0 - sum_val * math.exp(-x + s * math.log(x) - math.lgamma(s))
    else:
        b = x + 1.0 - s
        c = 1.0 / 1e-30
        d = 1.0 / b
        h = d
        for i in range(1, 150):
            an = -i * (i - s)
            b += 2.0
            d = an * d + b
            if abs(d) < 1e-30: d = 1e-30
            c = b + an / c
            if abs(c) < 1e-30: c = 1e-30
            d = 1.0 / d
            del_val = d * c
            h *= del_val
            if abs(del_val - 1.0) < 1e-12: break
        return math.exp(-x + s * math.log(x) - math.lgamma(s)) * h

def chi2_sf(x, df):
    if df <= 0: return 0.0
    return max(0.0, min(1.0, regularized_gamma_q(df / 2.0, x / 2.0)))

def run_steganalysis(image_path, step=2500):
    img = cv2.imread(image_path)
    if img is None:
        print(f"[-] Error: no se pudo abrir {image_path}")
        return
    
    H, W, C = img.shape
    total_samples = H * W * C
    print(f"[*] Analizando imagen: {image_path} ({W}x{H}, {C} canales, {total_samples} muestras)")
    
    samples = img.reshape(-1)
    counts = np.zeros(256, dtype=np.int64)
    
    milestones = []
    for i, val in enumerate(samples):
        counts[val] += 1
        if (i + 1) % step == 0 or i == total_samples - 1:
            c2 = 0.0
            df = 0
            for k in range(128):
                n0 = counts[2*k]
                n1 = counts[2*k+1]
                tot = n0 + n1
                if tot > 5:
                    df += 1
                    diff = n0 - n1
                    c2 += (diff * diff) / (2.0 * tot)
            df = max(1, df - 1)
            p = chi2_sf(c2, df)
            pct = (i + 1) / total_samples * 100.0
            milestones.append((pct, p))
            
    print("\n[+] Resumen de Muestreo Chi-Cuadrado:")
    print(f"    {'Progreso (%)':<15} {'Probabilidad P':<15} {'Diagnóstico'}")
    print("    " + "-" * 50)
    for pct, p in milestones[::max(1, len(milestones)//12)]:
        diag = "ESTEGANOGRAFÍA DETECTADA (Alta Certeza)" if p > 0.8 else ("SOSPECHOSO" if p > 0.4 else "Portador Natural / Limpio")
        print(f"    {pct:6.2f}%         {p:6.4f}          {diag}")
        
    last_pct, last_p = milestones[-1]
    diag = "ESTEGANOGRAFÍA DETECTADA" if last_p > 0.5 else "Portador Natural / Limpio"
    print(f"    {last_pct:6.2f}%         {last_p:6.4f}          {diag}")

if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else 'CAI2/CAI2-Parte2/Ejercicio y contenidos/Dibujo.bmp'
    run_steganalysis(target)
