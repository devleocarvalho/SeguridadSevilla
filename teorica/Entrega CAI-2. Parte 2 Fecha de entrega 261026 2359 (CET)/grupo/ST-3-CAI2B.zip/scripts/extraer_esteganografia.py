#!/usr/bin/env python3
"""
Script de Extracción Forense de Información Esteganográfica (Método LSB / VSL)
Seguridad en Sistemas Informáticos e Internet - CAI 2 Parte 2
Security Team 3 (ST-3)
"""
import os
import sys
import zipfile
import hashlib
import cv2

def extract_vsl_payload(image_path, output_bin):
    """Extrae el payload LSB siguiendo la especificación exacta de VSL 1.1."""
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"No se pudo cargar la imagen: {image_path}")
    
    H, W, C = img.shape
    # En VSL / Java BufferedImage getRGB():
    # layer 0 = Blue (bits 0-7), layer 1 = Green (bits 8-15), layer 2 = Red (bits 16-23)
    # y = fila, x = columna
    bits = []
    for y in range(H):
        for x in range(W):
            b = int(img[y, x, 0] & 1)
            g = int(img[y, x, 1] & 1)
            r = int(img[y, x, 2] & 1)
            bits.extend([b, g, r])
            
    # Reconstrucción del tamaño según LsbImpl.decode():
    size = 0
    for i in range(32):
        size = (size << 1) | bits[i]
        
    size2 = 0
    for j in range(32):
        size2 = (size2 << 1) | ((size >> j) & 1)
        
    total_bytes = size2
    print(f"[+] Longitud de mensaje recuperada de cabecera VSL: {total_bytes} bytes ({total_bytes * 8} bits)")
    max_payload = (len(bits) - 32) // 8
    if total_bytes <= 0 or total_bytes > max_payload:
        raise ValueError(f"Longitud inválida o portador alterado: {total_bytes} bytes (máx: {max_payload} bytes)")
        
    # Reconstrucción de bytes según Message.setNext():
    # ibuffer = ibuffer << 1 | newbit; if (++count == 8) msg[pos++] = (byte) ibuffer;
    payload_bits = bits[32 : 32 + (total_bytes * 8)]
    payload_bytes = bytearray()
    
    ibuffer = 0
    count = 0
    for bit in payload_bits:
        ibuffer = (ibuffer << 1) | bit
        count += 1
        if count == 8:
            payload_bytes.append(ibuffer & 0xFF)
            ibuffer = 0
            count = 0
            
    with open(output_bin, 'wb') as f:
        f.write(payload_bytes)
    print(f"[+] Payload binario exportado con éxito a: {output_bin} ({len(payload_bytes)} bytes)")
    return payload_bytes

def main():
    target = sys.argv[1] if len(sys.argv) > 1 else 'CAI2/CAI2-Parte2/Ejercicio y contenidos/Dibujo.bmp'
    out_dir = sys.argv[2] if len(sys.argv) > 2 else 'CAI2/CAI2-Parte2/Resultados'
    
    print("=" * 70)
    print(" EXTRACCIÓN PERICIAL DE INFORMACIÓN ESTEGANOGRÁFICA - ST-3")
    print("=" * 70)
    print(f"[*] Analizando portador: {target}")
    
    bin_path = os.path.join(out_dir, "payload_extraido.zip")
    payload = extract_vsl_payload(target, bin_path)
    
    md5 = hashlib.md5(payload).hexdigest()
    sha256 = hashlib.sha256(payload).hexdigest()
    print(f"[*] MD5 payload:    {md5}")
    print(f"[*] SHA-256 payload: {sha256}")
    
    if payload[:4] == b'PK\x03\x04':
        print("[!] FIRMA DETECTADA: Archivo comprimido ZIP (PK\\x03\\x04)")
        with zipfile.ZipFile(bin_path, 'r') as zf:
            print("[+] Archivos contenidos en el ZIP:")
            for info in zf.infolist():
                print(f"    - {info.filename} ({info.file_size} bytes)")
                zf.extract(info, out_dir)
                extracted_path = os.path.join(out_dir, info.filename)
                
                # Convertir a formato PNG crudo sin compresión destructiva
                if info.filename.lower().endswith(('.jpg', '.jpeg')):
                    png_name = os.path.splitext(info.filename)[0] + ".png"
                    png_target = os.path.join(out_dir, png_name)
                    img_jpg = cv2.imread(extracted_path)
                    cv2.imwrite(png_target, img_jpg)
                    print(f"    [+] Convertido y normalizado a formato crudo: {png_target}")
    else:
        print("[!] No se detectó firma ZIP estándar en los primeros 4 bytes.")

if __name__ == '__main__':
    main()
