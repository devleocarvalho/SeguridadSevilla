#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compilador de PDF para ST-3-CAI2B
Security Team 3 (ST-3)
"""
import os
import re
import subprocess
import markdown

BASE_DIR = "/home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Resultados"
MD_PATH = os.path.join(BASE_DIR, "ST-3-CAI2B.md")
PDF_PATH = os.path.join(BASE_DIR, "ST-3-CAI2B.pdf")
HTML_TEMP = os.path.join(BASE_DIR, "informe_temp.html")

def convert():
    with open(MD_PATH, "r", encoding="utf-8") as f:
        text = f.read()

    # Callouts conversion
    text = re.sub(
        r'> \[!IMPORTANT\]\n((?:> .*\n?)+)',
        lambda m: '<div class="callout callout-important"><strong>AVISO CRÍTICO DE SEGURIDAD:</strong><br/>' + m.group(1).replace('> ', '') + '</div>\n',
        text
    )
    text = re.sub(
        r'> \[!NOTE\]\n((?:> .*\n?)+)',
        lambda m: '<div class="callout callout-note"><strong>NOTA TÉCNICA:</strong><br/>' + m.group(1).replace('> ', '') + '</div>\n',
        text
    )
    text = re.sub(
        r'> \[!WARNING\]\n((?:> .*\n?)+)',
        lambda m: '<div class="callout callout-warning"><strong>ADVERTENCIA:</strong><br/>' + m.group(1).replace('> ', '') + '</div>\n',
        text
    )
    text = re.sub(
        r'> \[!CAUTION\]\n((?:> .*\n?)+)',
        lambda m: '<div class="callout callout-caution"><strong>EVIDENCIA FORENSE / CRÍTICA:</strong><br/>' + m.group(1).replace('> ', '') + '</div>\n',
        text
    )

    body_html = markdown.markdown(text, extensions=["tables", "fenced_code", "extra", "sane_lists"])

    html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<base href="file://{BASE_DIR}/">
<title>ST-3-CAI2B - Informe Pericial de Consultoría en Confidencialidad y Esteganografía</title>
<style>
  @page {{
    size: A4;
    margin: 10mm 12mm 10mm 12mm;
    @bottom-right {{
      content: "Página " counter(page) " de " counter(pages);
      font-size: 7.5pt;
      color: #64748b;
    }}
  }}
  .watermark {{
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) rotate(-45deg);
    font-size: 70pt;
    font-weight: 900;
    color: rgba(220, 38, 38, 0.040);
    z-index: 9999;
    pointer-events: none;
    letter-spacing: 12px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    user-select: none;
    text-transform: uppercase;
  }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    color: #1e293b;
    line-height: 1.33;
    font-size: 8.3pt;
    text-align: justify;
    text-justify: inter-word;
  }}
  h1 {{
    font-size: 13.5pt;
    color: #0f172a;
    border-bottom: 2px solid #b91c1c;
    padding-bottom: 3px;
    margin-top: 4px;
    margin-bottom: 4px;
    text-align: center;
    page-break-after: avoid;
  }}
  h2 {{
    font-size: 10.6pt;
    color: #0f172a;
    border-bottom: 1.5px solid #0284c7;
    padding-bottom: 2px;
    margin-top: 6px;
    margin-bottom: 3px;
    page-break-after: avoid;
    text-align: left;
  }}
  h3 {{
    font-size: 9.1pt;
    color: #1e3a8a;
    margin-top: 4px;
    margin-bottom: 2px;
    page-break-after: avoid;
    text-align: left;
  }}
  h4 {{
    font-size: 8.4pt;
    color: #334155;
    margin-top: 3px;
    margin-bottom: 2px;
    page-break-after: avoid;
    text-align: left;
  }}
  p {{
    margin-top: 2px;
    margin-bottom: 3.5px;
    text-align: justify;
    text-justify: inter-word;
  }}
  ul, ol {{
    margin-top: 2px;
    margin-bottom: 3.5px;
    padding-left: 16px;
    text-align: justify;
    text-justify: inter-word;
  }}
  li {{
    margin-bottom: 1.5px;
  }}
  table {{
    width: 100%;
    border-collapse: collapse;
    margin: 4px 0 5px 0;
    font-size: 7.6pt;
    page-break-inside: avoid;
  }}
  th, td {{
    border: 1px solid #cbd5e1;
    padding: 2.0px 4.0px;
    text-align: left;
  }}
  th {{
    background-color: #f1f5f9;
    color: #0f172a;
    font-weight: 600;
  }}
  tr:nth-child(even) {{
    background-color: #f8fafc;
  }}
  code {{
    font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
    font-size: 7.3pt;
    background-color: #f1f5f9;
    padding: 1px 3px;
    border-radius: 3px;
    color: #0f172a;
  }}
  pre {{
    background-color: #0f172a;
    color: #f8fafc;
    padding: 4px 7px;
    border-radius: 4px;
    font-size: 6.9pt;
    line-height: 1.25;
    margin: 3px 0;
    overflow-x: auto;
    page-break-inside: avoid;
    text-align: left;
  }}
  pre code {{
    background-color: transparent;
    color: #f8fafc;
    padding: 0;
  }}
  .callout {{
    padding: 4px 7px;
    margin: 3px 0;
    border-left: 3.5px solid #0284c7;
    background-color: #f0f9ff;
    font-size: 7.7pt;
    page-break-inside: avoid;
    text-align: justify;
    text-justify: inter-word;
  }}
  .callout-important {{
    border-left-color: #b91c1c;
    background-color: #fef2f2;
  }}
  .callout-warning {{
    border-left-color: #d97706;
    background-color: #fffbeb;
  }}
  .callout-caution {{
    border-left-color: #b91c1c;
    background-color: #fef2f2;
  }}
  .callout-note {{
    border-left-color: #0284c7;
    background-color: #f0f9ff;
  }}
  .page-break {{
    page-break-after: always;
    break-after: page;
  }}
</style>
</head>
<body>
<div class="watermark">CONFIDENCIAL</div>
{body_html}
</body>
</html>"""

    with open(HTML_TEMP, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"[*] Compilando PDF ST-3-CAI2B.pdf mediante Brave headless...")
    cmd = [
        "brave",
        "--headless",
        "--disable-gpu",
        "--no-sandbox",
        f"--print-to-pdf={PDF_PATH}",
        HTML_TEMP
    ]
    subprocess.run(cmd, check=True)

    if os.path.exists(HTML_TEMP):
        os.remove(HTML_TEMP)

    if os.path.exists(PDF_PATH):
        pdfinfo = subprocess.check_output(["pdfinfo", PDF_PATH], text=True)
        pages_match = re.search(r"Pages:\s+(\d+)", pdfinfo)
        pages = int(pages_match.group(1)) if pages_match else 0
        size_kb = os.path.getsize(PDF_PATH) / 1024
        print(f"[OK] Documento PDF generado exitosamente: {PDF_PATH}")
        print(f"     Páginas: {pages} (Límite normativo: exactamente máx. 10 páginas) | Tamaño: {size_kb:.1f} KB")
        return pages
    return None

if __name__ == '__main__':
    convert()
