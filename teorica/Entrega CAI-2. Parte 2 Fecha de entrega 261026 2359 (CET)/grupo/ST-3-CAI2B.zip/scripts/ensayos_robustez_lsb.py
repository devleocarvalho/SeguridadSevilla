#!/usr/bin/env python3
"""
Ensayos Experimentales de Robustez LSB frente a Distorsiones (Salt & Pepper y Recorte/Crop)
Seguridad en Sistemas Informáticos e Internet - CAI 2 Parte 2
Security Team 3 (ST-3)
"""
import os
import subprocess
import cv2
import numpy as np

def calculate_psnr(img1, img2):
    mse = np.mean((img1.astype(np.float64) - img2.astype(np.float64)) ** 2)
    if mse == 0:
        return float('inf')
    return 20 * np.log10(255.0 / np.sqrt(mse))

def main():
    print("=" * 75)
    print(" BANCO DE PRUEBAS DE ROBUSTEZ LSB - DISTORSIONES ESPACIALES - ST-3")
    print("=" * 75)
    
    # Resolver rutas absolutas para que funcione desde cualquier directorio
    script_dir = os.path.dirname(os.path.abspath(__file__))
    res_dir = os.path.dirname(script_dir)
    cai2_p2_dir = os.path.dirname(res_dir)
    ssii_dir = os.path.dirname(os.path.dirname(cai2_p2_dir))
    vsl_dir = os.path.join(cai2_p2_dir, "Ejercicio y contenidos", "vsl-1.1")
    
    cp_lsb = f"{os.path.join(vsl_dir, 'modules', 'vsl-module-steganography-lsb.jar')}:{os.path.join(vsl_dir, 'lib', '*')}"
    cp_sp = f"{os.path.join(vsl_dir, 'modules', 'vsl-module-distortion-salt-pepper-noise.jar')}:{os.path.join(vsl_dir, 'lib', '*')}"
    cp_crop = f"{os.path.join(vsl_dir, 'modules', 'vsl-module-distortion-cropping.jar')}:{os.path.join(vsl_dir, 'lib', '*')}"
    
    cover_img = os.path.join(ssii_dir, "CAI2", "apartado_a", "radiografia_tamano1_500KB.bmp")
    if not os.path.exists(cover_img):
        cover_img = os.path.join(cai2_p2_dir, "Ejercicio y contenidos", "Dibujo.bmp")
        
    stego_img = "/tmp/stego_radio_exp.bmp"
    sig_file = "/tmp/sig_medico_512.txt"
    
    sig_text = (
        "HOSPITAL UNIVERSITARIO VIRGEN DEL ROCIO | SERVICIO DE RADIODIAGNOSTICO E IMAGEN MEDICA | "
        "FACULTATIVO: DR. ALEJANDRO NAVARRO RUIZ | COLEGIADO: 41/08832 | NIF: 28945612X | "
        "PACIENTE REF: PAC-2026-99410 | ESTUDIO: RADIOGRAFIA TORACICA DIGITAL PA Y LATERAL | "
        "INDICACION CLINICA: CONTROL EVOLUTIVO CONDENSACION LOBAR | "
        "HALLAZGOS: RESOLUCION COMPLETA DE INFILTRADOS, SILUETA CARDIACA DENTRO DE LIMITES NORMALES | "
        "FECHA: 2026-10-23T11:45:00Z | FIRMA DIGITAL SHA256: 7b3d8f1e4a9c2b5e8f0a1c3d5e7f9a2b4c6e8f0a1c3d5e7f9a2b4c6e8f0a1c3d"
    )[:512]
    
    with open(sig_file, 'wb') as f:
        f.write(sig_text.encode('utf-8'))
        
    res_enc = subprocess.run([
        'java', '-cp', cp_lsb, 'pl.edu.zut.wi.vsl.modules.steganography.lsb.LsbImpl',
        cover_img, sig_file, stego_img, '0', '0'
    ], capture_output=True, text=True)
    if res_enc.returncode != 0:
        print(f"[-] Error en incrustación LSB: {res_enc.stderr}")
        return
    print(f"[+] Firma clínica (512 B) incrustada con éxito en radiografía.")

    img_clean = cv2.imread(cover_img)
    img_stego = cv2.imread(stego_img)
    print(f"[+] PSNR Portador Original vs Estego-Objeto: {calculate_psnr(img_clean, img_stego):.2f} dB (Imperceptible)\n")

    print("[*] TEST 1: 4 Órdenes de Distorsión Salt & Pepper Noise:")
    print(f"    {'Orden':<8} {'Densidad':<12} {'PSNR (dB)':<12} {'Bytes Alterados':<18} {'BER (%)':<10} {'Estado Decodificación'}")
    print("    " + "-" * 75)
    
    sp_densities = [0.005, 0.010, 0.020, 0.050]
    for idx, d in enumerate(sp_densities, 1):
        distorted_path = f"/tmp/exp_sp_{d}.bmp"
        decoded_path = f"/tmp/dec_exp_sp_{d}.txt"
        subprocess.run(['java', '-cp', cp_sp, 'pl.edu.zut.wi.vsl.modules.distortions.SaltPepperImpl', str(d), stego_img, distorted_path], capture_output=True)
        img_dist = cv2.imread(distorted_path)
        psnr_val = calculate_psnr(img_stego, img_dist)
        
        res_dec = subprocess.run(['java', '-cp', cp_lsb, 'pl.edu.zut.wi.vsl.modules.steganography.lsb.LsbImpl', distorted_path, decoded_path, '0', '0'], capture_output=True, text=True)
        if res_dec.returncode == 0:
            with open(decoded_path, 'rb') as f:
                dec_bytes = f.read()
            diffs = sum(1 for a, b in zip(sig_text.encode('utf-8'), dec_bytes) if a != b)
            ber = (diffs / 512.0) * 100.0
            status = "RECUPERADO CON ERRORES" if diffs > 0 else "INTEGRO 100%"
            print(f"    Orden {idx:<2} {d*100:>4.1f}%       {psnr_val:>6.2f} dB     {diffs:>3}/512 B          {ber:>5.2f}%     {status}")
        else:
            print(f"    Orden {idx:<2} {d*100:>4.1f}%       {psnr_val:>6.2f} dB     Fallo de Cabecera   100.00%    ERROR FATAL VSL")

    print("\n[*] TEST 2: 4 Órdenes de Distorsión Crop (Recorte Perimetral W/H):")
    print(f"    {'Orden':<8} {'Dimensiones':<14} {'Recorte':<10} {'PSNR (dB)':<12} {'BER (%)':<10} {'Estado Decodificación'}")
    print("    " + "-" * 75)
    
    crops = [(405, 405, "2%"), (392, 392, "5%"), (371, 371, "10%"), (330, 330, "20%")]
    for idx, (w, h, label) in enumerate(crops, 1):
        distorted_path = f"/tmp/exp_crop_{w}x{h}.bmp"
        decoded_path = f"/tmp/dec_exp_crop_{w}x{h}.txt"
        subprocess.run(['java', '-cp', cp_crop, 'pl.edu.zut.wi.vsl.modules.distortions.CroppingImpl', '0', '0', str(w), str(h), stego_img, distorted_path], capture_output=True)
        img_dist = cv2.imread(distorted_path)
        psnr_val = calculate_psnr(img_stego[:h, :w], img_dist)
        
        res_dec = subprocess.run(['java', '-cp', cp_lsb, 'pl.edu.zut.wi.vsl.modules.steganography.lsb.LsbImpl', distorted_path, decoded_path, '0', '0'], capture_output=True, text=True)
        if res_dec.returncode == 0:
            with open(decoded_path, 'rb') as f:
                dec_bytes = f.read()
            diffs = sum(1 for a, b in zip(sig_text.encode('utf-8'), dec_bytes) if a != b)
            ber = (diffs / 512.0) * 100.0
            print(f"    Orden {idx:<2} {w}x{h:<8}   {label:<8}   {psnr_val:>6.2f} dB     {ber:>5.2f}%     DESALINEACIÓN ESPACIAL")
        else:
            print(f"    Orden {idx:<2} {w}x{h:<8}   {label:<8}   {psnr_val:>6.2f} dB     100.00%    ERROR CABECERA DESTRUIDA")

if __name__ == '__main__':
    main()
