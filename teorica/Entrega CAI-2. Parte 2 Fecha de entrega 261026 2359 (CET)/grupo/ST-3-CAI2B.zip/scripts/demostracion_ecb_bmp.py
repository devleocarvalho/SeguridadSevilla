#!/usr/bin/env python3
"""
Demostración Forense de Filtración Visual en Cifrado ECB sobre Imágenes BMP
Seguridad en Sistemas Informáticos e Internet - CAI 2 Parte 2
Security Team 3 (ST-3)
"""
import os
import cv2
import numpy as np
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def main():
    print("=" * 75)
    print(" ANÁLISIS FORENSE: VULNERABILIDAD ECB EN FIRMAS DIGITALIZADAS BMP - ST-3")
    print("=" * 75)
    
    out_dir = "CAI2/CAI2-Parte2/Resultados/apartado_c"
    os.makedirs(out_dir, exist_ok=True)
    
    # 1. Crear firma manuscrita digitalizada simulada
    W, H = 512, 256
    img = np.ones((H, W, 3), dtype=np.uint8) * 255
    cv2.rectangle(img, (20, 20), (W-20, H-20), (0, 0, 0), 2)
    cv2.putText(img, 'HOSPITAL UNIVERSITARIO VIRGEN DEL ROCIO', (35, 55), cv2.FONT_HERSHEY_DUPLEX, 0.6, (0, 0, 0), 1, cv2.LINE_AA)
    cv2.putText(img, 'SERVICIO DE RADIODIAGNOSTICO', (35, 80), cv2.FONT_HERSHEY_DUPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
    cv2.putText(img, 'Facultativo: Dr. Alejandro Navarro Ruiz', (35, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
    cv2.putText(img, 'NIF: 28945612X    Col. Medico: 41/08832', (35, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
    pts = np.array([[50, 210], [90, 160], [130, 220], [180, 150], [220, 190], [280, 160], [350, 210], [420, 170]], np.int32).reshape((-1, 1, 2))
    cv2.polylines(img, [pts], isClosed=False, color=(0, 0, 0), thickness=3, lineType=cv2.LINE_AA)
    cv2.circle(img, (380, 180), 25, (0, 0, 0), 2, lineType=cv2.LINE_AA)
    cv2.line(img, (50, 225), (450, 220), (0, 0, 0), 2, lineType=cv2.LINE_AA)
    
    orig_bmp = os.path.join(out_dir, "firma_medico_original.bmp")
    cv2.imwrite(orig_bmp, img)
    
    with open(orig_bmp, 'rb') as f:
        bmp_data = f.read()
    header, pixel_data = bmp_data[:54], bmp_data[54:]
    
    pad_len = 16 - (len(pixel_data) % 16)
    if pad_len != 16:
        pixel_data += b'\x00' * pad_len
        
    key = os.urandom(32) # AES-256
    
    # Cifrado ECB
    cipher_ecb = Cipher(algorithms.AES(key), modes.ECB(), backend=default_backend()).encryptor()
    enc_ecb = cipher_ecb.update(pixel_data) + cipher_ecb.finalize()
    with open(os.path.join(out_dir, "firma_medico_cifrada_ecb.bmp"), 'wb') as f:
        f.write(header + enc_ecb[:len(bmp_data)-54])
        
    # Cifrado CBC
    iv = os.urandom(16)
    cipher_cbc = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend()).encryptor()
    enc_cbc = cipher_cbc.update(pixel_data) + cipher_cbc.finalize()
    with open(os.path.join(out_dir, "firma_medico_cifrada_cbc.bmp"), 'wb') as f:
        f.write(header + enc_cbc[:len(bmp_data)-54])
        
    print("[+] Archivos BMP generados con éxito:")
    print("    - firma_medico_original.bmp (Texto plano)")
    print("    - firma_medico_cifrada_ecb.bmp (Vulnerable a filtración visual)")
    print("    - firma_medico_cifrada_cbc.bmp (Modo encadenado seguro)")

if __name__ == '__main__':
    main()
