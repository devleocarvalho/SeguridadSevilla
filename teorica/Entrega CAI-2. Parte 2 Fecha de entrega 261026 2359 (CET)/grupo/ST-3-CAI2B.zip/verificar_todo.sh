#!/usr/bin/env bash
# ==============================================================================
# SCRIPT DE VERIFICACIÓN TOTAL DE PRUEBAS - ST-3 (CAI 2 - PARTE 2)
# ==============================================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

DIBUJO_PATH="../Ejercicio y contenidos/Dibujo.bmp"
if [ ! -f "$DIBUJO_PATH" ]; then
    DIBUJO_PATH="/home/thespace81/Documentos/SSII/CAI2/CAI2-Parte2/Ejercicio y contenidos/Dibujo.bmp"
fi

echo "======================================================================"
echo " INICIANDO VERIFICACIÓN COMPLETA DE PRUEBAS - SECURITY TEAM 3"
echo "======================================================================"

echo -e "\n[1/5] Verificando Informe Oficial ST-3-CAI2B.pdf..."
if [ -f "ST-3-CAI2B.pdf" ]; then
    PAGES=$(pdfinfo ST-3-CAI2B.pdf | grep "Pages:" | awk '{print $2}')
    SIZE=$(du -h ST-3-CAI2B.pdf | awk '{print $1}')
    echo "  [OK] ST-3-CAI2B.pdf encontrado ($SIZE, $PAGES páginas)"
    if [ "$PAGES" -eq 10 ]; then
        echo "  [OK] El informe cumple estrictamente el límite normativo de 10 páginas."
    else
        echo "  [ALERTA] El número de páginas es $PAGES (se esperaban 10 páginas exactas)."
    fi
else
    echo "  [ERROR] No se encontró ST-3-CAI2B.pdf"
fi

echo -e "\n[2/5] Ejecutando Extracción Forense en Dibujo.bmp..."
python3 scripts/extraer_esteganografia.py "$DIBUJO_PATH" "$DIR"
if [ -f "a5fde.png" ]; then
    echo "  [OK] Evidencia extraída correctamente: a5fde.png"
fi

echo -e "\n[3/5] Ejecutando Estegoanálisis Chi-Cuadrado (Independiente a VSL)..."
python3 scripts/analisis_chicuadrado.py "$DIBUJO_PATH"

echo -e "\n[4/5] Ejecutando Banco de Pruebas de Robustez (Salt & Pepper y Crop)..."
python3 scripts/ensayos_robustez_lsb.py

echo -e "\n[5/5] Ejecutando Demostración de Filtración Visual en Modo ECB..."
python3 scripts/demostracion_ecb_bmp.py

echo -e "\n======================================================================"
echo " TODAS LAS PRUEBAS HAN SIDO EJECUTADAS Y VERIFICADAS CON ÉXITO [ST-3]"
echo " Paquete de entrega listo en: ST-3-CAI2B.zip y ST-3-CAI2B.pdf"
echo "======================================================================"
